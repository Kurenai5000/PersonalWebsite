#include "raylib.h"

//vars
int gridX = 0;
int gridY = 0;
int xIncrease = 40;
int yIncrease = 40;

//unit
int unitX = 0;
int unitY = 0;

//funcs

void map(){
  //Outer 
  //DrawRectangle(0, 0, 800, 10, BLACK); 
  DrawRectangle(0, 790, 800, 10, BLACK); 
  //DrawRectangle(0, 0, 10, 800, BLACK); 
  DrawRectangle(790, 0, 10, 800, BLACK);
  //grid
  //x 
  DrawRectangle(0, 90, 800, 10, BLACK); 
  DrawRectangle(0, 190, 800, 10, BLACK);
  DrawRectangle(0, 290, 800, 10, BLACK);
  DrawRectangle(0, 390, 800, 10, BLACK); 
  DrawRectangle(0, 490, 800, 10, BLACK);
  DrawRectangle(0, 590, 800, 10, BLACK);
  DrawRectangle(0, 690, 800, 10, BLACK); 
  
  

  //Y
  DrawRectangle(90, 0, 10, 800, BLACK); 
  DrawRectangle(190, 0, 10, 800, BLACK);
  DrawRectangle(290, 0, 10, 800, BLACK);
  DrawRectangle(390, 0, 10, 800, BLACK); 
  DrawRectangle(490, 0, 10, 800, BLACK);
  DrawRectangle(590, 0, 10, 800, BLACK);
  DrawRectangle(690, 0, 10, 800, BLACK); 
}

void unit(){
  DrawRectangle(unitX, unitY, 100, 100, BLACK); 
  if(IsKeyPressed(KEY_W)&& unitY > 0){unitY -= 100;}
  if(IsKeyPressed(KEY_S)&& unitY < 690){unitY += 100;}
  if(IsKeyPressed(KEY_D)&& unitX < 690){unitX += 100;}
  if(IsKeyPressed(KEY_A)&& unitX > 0){unitX -= 100;}

}



int main(void){

//screen init

const int screenWidth = 800;
const int screenHeight = 800;

InitWindow(screenWidth, screenHeight, "Grid movement");

SetTargetFPS(60);

//main loop
  while(!WindowShouldClose()){
  //updates

  //draws
  BeginDrawing();

  ClearBackground(RAYWHITE);
  //map
  map();
  //units
  unit();


  EndDrawing();

  }

CloseWindow();

return 0;

}
