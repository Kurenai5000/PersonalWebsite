#include "raylib.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"

//------------------------------------------------------------------------------------
// Program main entry point
//------------------------------------------------------------------------------------


//vars
int score = 0;
char scoreText[10];

//chracter
int movX = 0;
int movY = 0;
int speed = 3;

//block
int randPosX = 650;
int randPosY = 300;

int bRandPosX = 400;
int bRandPosY = 400;


//functions
void character() {
  DrawRectangle(movX, movY, 50, 50, BLUE); 
  //movement
  if (IsKeyDown(KEY_W)){movY = movY - speed;}
  if (IsKeyDown(KEY_S)){movY = movY + speed;}
  if (IsKeyDown(KEY_A)){movX = movX - speed;}
  if (IsKeyDown(KEY_D)){movX = movX + speed;}
  //reset
  if ((movX <= 0 || movX >= 1280) || (movY <= 0 || movY >= 720)){
  speed = 3;
  score = 0;
  }
  //boundaries
  if (movX <= 0){movX = 650; movY = 300;}
  if (movX >= 1280){movX = 650; movY = 300;}
  if (movY <= 0){movX = 650; movY = 300;}
  if (movY >= 720){movX = 650; movY = 300;}
  
}

void block(){
srand(time(NULL));
  if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
    if ((movX > randPosX - 50 && movX < randPosX + 50) && (movY > randPosY - 50 && movY < randPosY + 50)){
      randPosX = rand() % 1231;
      randPosY = rand() % 671;

      bRandPosX = rand() % 1231;
      bRandPosY = rand() % 671;
      score = score + 1;
    }
  }

  DrawRectangle(randPosX, randPosY, 50, 50, BLUE); 

}

void badBlock(){
srand(time(NULL)+1);
  if (IsMouseButtonPressed(MOUSE_BUTTON_LEFT)) {
    if ((movX > bRandPosX - 50 && movX < bRandPosX + 50) && (movY > bRandPosY - 50 && movY < bRandPosY + 50)){
      bRandPosX = rand() % 1231;
      bRandPosY = rand() % 671;
    
      randPosX = rand() % 1231;
      randPosY = rand() % 671;
      score = 0;
    }
  }

  DrawRectangle(bRandPosX, bRandPosY, 50, 50, RED); 

}



int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 1280;
    const int screenHeight = 720;

    InitWindow(screenWidth, screenHeight, "Go to block");

    SetTargetFPS(60);               // Set our game to run at 60 frames-per-second
    //--------------------------------------------------------------------------------------
 
    //srand(time(NULL));
   
    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update
        //----------------------------------------------------------------------------------
        // TODO: Update your variables here
        //----------------------------------------------------------------------------------
        snprintf(scoreText, sizeof(scoreText), "%d", score);

        movX = GetMouseX();
        movY = GetMouseY();
        // Draw
        //----------------------------------------------------------------------------------
        BeginDrawing();

            ClearBackground(RAYWHITE);
          
            //units
            //character(); 
            
            block();
            badBlock();
            //text
            DrawText("Score =", 540, 50, 40, BLACK);
            DrawText(scoreText, 710, 50, 40, BLACK);

        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------

    return 0;
}
