#include "raylib.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"
#include "string.h"

//------------------------------------------------------------------------------------
// Program main entry point
//------------------------------------------------------------------------------------


//vars
int score = 0;
char scoreText[10];

//chracter
int movX = 0;
int movY = 0;
int speed = 3;

//createBlock
int curMouseX = 0;
int curMouseY = 0;

//randomiser
int randomNumber = 0;
char colorContainer[10];
Color color; 

//functions
void randomiser(){
  srand(time(NULL));

  randomNumber = rand() % 8;

  if (randomNumber == 0) {strcpy(colorContainer, "BLUE");}
  if (randomNumber == 1) {strcpy(colorContainer, "GOLD");}
  if (randomNumber == 2) {strcpy(colorContainer, "RED");}
  if (randomNumber == 3) {strcpy(colorContainer, "ORANGE");}
  if (randomNumber == 4) {strcpy(colorContainer, "YELLOW");}
  if (randomNumber == 5) {strcpy(colorContainer, "GREEN");}
  if (randomNumber == 6) {strcpy(colorContainer, "PINK");}
  if (randomNumber == 7) {strcpy(colorContainer, "PURPLE");}
  if (randomNumber == 8) {strcpy(colorContainer, "BLACK");}

}

void randomiser2(){
  srand(time(NULL));

  randomNumber = rand() % 9;

  if (randomNumber == 0) {color = BLUE;}
  if (randomNumber == 1) {color = GOLD;}
  if (randomNumber == 2) {color =  RED;}
  if (randomNumber == 3) {color = ORANGE;}
  if (randomNumber == 4) {color = YELLOW;}
  if (randomNumber == 5) {color = GREEN;}
  if (randomNumber == 6) {color = PINK;}
  if (randomNumber == 7) {color = PURPLE;}
  if (randomNumber == 8) {color = BLACK;}

}


void createBlock(){
  curMouseX = GetMouseX();
  curMouseY = GetMouseY();

  if(IsMouseButtonDown(MOUSE_BUTTON_LEFT)) {
  DrawRectangle(curMouseX, curMouseY, 10, 10, BLACK); 
  }
  if(IsMouseButtonDown(MOUSE_BUTTON_RIGHT)) {
  DrawRectangle(curMouseX, curMouseY, 20, 20, RAYWHITE); 
  }
}




int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 1280;
    const int screenHeight = 720;

    InitWindow(screenWidth, screenHeight, "Go to block");

    SetTargetFPS(60);    
    ClearBackground(RAYWHITE); 
          // Set our game to run at 60 frames-per-second
    //--------------------------------------------------------------------------------------
 
    

    
   
    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update
        //----------------------------------------------------------------------------------
        // TODO: Update your variables here
        //----------------------------------------------------------------------------------
        //snprintf(scoreText, sizeof(scoreText), "%d", score);
        //randomiser();
        //randomiser2();

        movX = GetMouseX();
        movY = GetMouseY();
        // Draw
        //----------------------------------------------------------------------------------
        BeginDrawing();

            //ClearBackground(RAYWHITE);
          
            //units
            //character(); 
            
            createBlock();
            
    
        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------

    return 0;
}
