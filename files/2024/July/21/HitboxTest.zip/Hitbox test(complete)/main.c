#include "raylib.h"
#include "stdlib.h"
#include "stdio.h"
#include "time.h"
#include "stdbool.h"

//------------------------------------------------------------------------------------
// Program main entry point
//------------------------------------------------------------------------------------


//vars
int score = 0;
char scoreText[10];

//chracter
int movX = 650;
int movY = 300;
int speed = 3;
bool hit = false;

//block
int randPosX = 650;
int randPosY = 300;

char xPos[10];

char yPos[10];


//functions
void character() {
  DrawRectangle(movX, movY, 50, 50, BLUE); 
  //movement
  if (IsKeyDown(KEY_W)){movY = movY - speed;}
  if (IsKeyDown(KEY_S)){movY = movY + speed;}
  if (IsKeyDown(KEY_A)){movX = movX - speed;}
  if (IsKeyDown(KEY_D)){movX = movX + speed;}
  //reset
  if ((movX <= 0 || movX >= 1280) || (movY <= 0 || movY >= 720)){
  speed = 3;
  score = 0;
  }
  //boundaries
  if (movX <= 0){movX = 650; movY = 300;}
  if (movX >= 1280){movX = 650; movY = 300;}
  if (movY <= 0){movX = 650; movY = 300;}
  if (movY >= 720){movX = 650; movY = 300;}
  

 //hitbox
 if (hit == true){
   score = score + 1;
 }
 
 

}

void block(int x,int y,int width,int height){
  DrawRectangle(x, y, width, height, PINK); 
            if (((movX > x || movX + 50 > x) && (movX < x + width || movX+50 < x+width)) && ((movY > y || movY+50 > y) && (movY < y + height || movY+50 < y+height))){
            hit = true;
            }
            else {hit= false;}
}



int main(void)
{
    // Initialization
    //--------------------------------------------------------------------------------------
    const int screenWidth = 1280;
    const int screenHeight = 720;

    InitWindow(screenWidth, screenHeight, "Go to block");

    SetTargetFPS(60);               // Set our game to run at 60 frames-per-second
    //--------------------------------------------------------------------------------------
 
    srand(time(NULL));
   
    // Main game loop
    while (!WindowShouldClose())    // Detect window close button or ESC key
    {
        // Update
        //----------------------------------------------------------------------------------
        // TODO: Update your variables here
        //----------------------------------------------------------------------------------
        snprintf(scoreText, sizeof(scoreText), "%d", score);

        snprintf(xPos, sizeof(xPos), "%d", movX);
        snprintf(yPos, sizeof(yPos), "%d", movY);
        //xMousePos = GetMouseX();
        //yMousePos = GetMouseY();


        // Draw
        //----------------------------------------------------------------------------------
        BeginDrawing();

            ClearBackground(RAYWHITE);
          
            //units
            character(); 
            
            block(500,500, 100,150);
            
            //block(700,300, 100,50);
            //text
            DrawText("Score =", 540, 50, 40, BLACK);
            DrawText(scoreText, 710, 50, 40, BLACK);
            //markers
            DrawText("Xpos =", 540, 150, 40, BLACK);
            DrawText(xPos, 710, 150, 40, BLACK);
            DrawText("YPos =", 540, 250, 40, BLACK);
            DrawText(yPos, 710, 250, 40, BLACK);


        EndDrawing();
        //----------------------------------------------------------------------------------
    }

    // De-Initialization
    //--------------------------------------------------------------------------------------
    CloseWindow();        // Close window and OpenGL context
    //--------------------------------------------------------------------------------------

    return 0;
}
